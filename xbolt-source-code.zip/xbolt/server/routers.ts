import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import {
  upsertUser,
  getUserByOpenId,
  getAllUsers,
  updateUserRole,
  createShipment,
  getShipmentById,
  getShipmentByTracking,
  getUserShipments,
  getAllShipments,
  getEmployeeShipments,
  updateShipmentStatus,
  updateShipmentPayment,
  getShipmentStats,
  addShipmentEvent,
  getShipmentEvents,
  addPointsTransaction,
  getUserPointsHistory,
  createNotification,
  getUserNotifications,
  markNotificationRead,
  markAllNotificationsRead,
  getUnreadNotificationsCount,
} from "./db";

// ─── Admin guard ─────────────────────────────────────────────────────────────
const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN", message: "ليس لديك صلاحية الوصول" });
  return next({ ctx });
});

const employeeProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin" && ctx.user.role !== "employee")
    throw new TRPCError({ code: "FORBIDDEN", message: "ليس لديك صلاحية الوصول" });
  return next({ ctx });
});

// ─── Price calculation helper ─────────────────────────────────────────────────
function calculatePrice(
  type: "local" | "international",
  weight: number,
  expressDelivery: boolean,
  insurance: boolean,
  packagingService: boolean,
  signatureRequired: boolean
): { basePrice: number; extraServicesPrice: number; totalPrice: number } {
  let basePrice = type === "local" ? 25 : 80;
  if (weight > 1) basePrice += (weight - 1) * (type === "local" ? 5 : 15);

  let extraServicesPrice = 0;
  if (expressDelivery) extraServicesPrice += type === "local" ? 20 : 50;
  if (insurance) extraServicesPrice += 15;
  if (packagingService) extraServicesPrice += 10;
  if (signatureRequired) extraServicesPrice += 5;

  return { basePrice, extraServicesPrice, totalPrice: basePrice + extraServicesPrice };
}

export const appRouter = router({
  system: systemRouter,

  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ─── Shipments ─────────────────────────────────────────────────────────────
  shipments: router({
    calculatePrice: publicProcedure
      .input(
        z.object({
          type: z.enum(["local", "international"]),
          weight: z.number().min(0.1),
          expressDelivery: z.boolean().default(false),
          insurance: z.boolean().default(false),
          packagingService: z.boolean().default(false),
          signatureRequired: z.boolean().default(false),
        })
      )
      .query(({ input }) => {
        return calculatePrice(
          input.type,
          input.weight,
          input.expressDelivery,
          input.insurance,
          input.packagingService,
          input.signatureRequired
        );
      }),

    create: protectedProcedure
      .input(
        z.object({
          type: z.enum(["local", "international"]),
          senderName: z.string().min(2),
          senderPhone: z.string().min(9),
          senderEmail: z.string().email().optional(),
          senderCountry: z.string(),
          senderCity: z.string(),
          senderAddress: z.string(),
          senderDistrict: z.string().optional(),
          senderPostalCode: z.string().optional(),
          receiverName: z.string().min(2),
          receiverPhone: z.string().min(9),
          receiverEmail: z.string().email().optional(),
          receiverCountry: z.string(),
          receiverCity: z.string(),
          receiverAddress: z.string(),
          receiverDistrict: z.string().optional(),
          receiverPostalCode: z.string().optional(),
          packageType: z.enum(["document", "parcel", "fragile", "heavy"]).default("parcel"),
          weight: z.number().min(0.1),
          length: z.number().optional(),
          width: z.number().optional(),
          height: z.number().optional(),
          description: z.string().optional(),
          declaredValue: z.number().optional(),
          insurance: z.boolean().default(false),
          expressDelivery: z.boolean().default(false),
          signatureRequired: z.boolean().default(false),
          packagingService: z.boolean().default(false),
          paymentMethod: z.enum(["online", "bank_transfer", "cash"]).optional(),
          notes: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const pricing = calculatePrice(
          input.type,
          input.weight,
          input.expressDelivery,
          input.insurance,
          input.packagingService,
          input.signatureRequired
        );

        const shipment = await createShipment({
          ...input,
          userId: ctx.user.id,
          basePrice: pricing.basePrice.toString(),
          extraServicesPrice: pricing.extraServicesPrice.toString(),
          totalPrice: pricing.totalPrice.toString(),
          weight: input.weight.toString(),
          length: input.length?.toString(),
          width: input.width?.toString(),
          height: input.height?.toString(),
          declaredValue: input.declaredValue?.toString(),
          status: "pending_payment",
          paymentStatus: "pending",
        });

        if (shipment) {
          await addShipmentEvent({
            shipmentId: shipment.id,
            status: "pending",
            description: "تم إنشاء طلب الشحن بنجاح",
            location: input.senderCity,
            createdBy: ctx.user.id,
          });

          await createNotification({
            userId: ctx.user.id,
            shipmentId: shipment.id,
            title: "تم إنشاء شحنتك",
            message: `تم إنشاء شحنتك بنجاح. رقم التتبع: ${shipment.trackingNumber}`,
            type: "status_update",
          });
        }

        return shipment;
      }),

    myShipments: protectedProcedure.query(async ({ ctx }) => {
      return getUserShipments(ctx.user.id);
    }),

    getById: protectedProcedure.input(z.object({ id: z.number() })).query(async ({ ctx, input }) => {
      const shipment = await getShipmentById(input.id);
      if (!shipment) throw new TRPCError({ code: "NOT_FOUND" });
      if (shipment.userId !== ctx.user.id && ctx.user.role === "user")
        throw new TRPCError({ code: "FORBIDDEN" });
      return shipment;
    }),

    track: publicProcedure
      .input(z.object({ trackingNumber: z.string() }))
      .query(async ({ input }) => {
        const shipment = await getShipmentByTracking(input.trackingNumber);
        if (!shipment) throw new TRPCError({ code: "NOT_FOUND", message: "رقم التتبع غير موجود" });
        const events = await getShipmentEvents(shipment.id);
        return { shipment, events };
      }),

    confirmPayment: protectedProcedure
      .input(
        z.object({
          shipmentId: z.number(),
          paymentMethod: z.enum(["online", "bank_transfer", "cash"]),
          paymentProofUrl: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const shipment = await getShipmentById(input.shipmentId);
        if (!shipment) throw new TRPCError({ code: "NOT_FOUND" });
        if (shipment.userId !== ctx.user.id && ctx.user.role === "user")
          throw new TRPCError({ code: "FORBIDDEN" });

        const paymentStatus =
          input.paymentMethod === "bank_transfer" ? "pending" : "paid";
        const newStatus =
          input.paymentMethod === "bank_transfer" ? "pending" : "confirmed";

        await updateShipmentPayment(
          input.shipmentId,
          input.paymentMethod,
          paymentStatus,
          input.paymentProofUrl
        );
        await updateShipmentStatus(input.shipmentId, newStatus);

        await addShipmentEvent({
          shipmentId: input.shipmentId,
          status: newStatus,
          description:
            input.paymentMethod === "bank_transfer"
              ? "تم استلام صورة التحويل البنكي، في انتظار التحقق"
              : "تم تأكيد الدفع وقبول الشحنة",
          createdBy: ctx.user.id,
        });

        if (paymentStatus === "paid") {
          await addPointsTransaction({
            userId: ctx.user.id,
            shipmentId: input.shipmentId,
            type: "earn",
            points: Math.floor(parseFloat(shipment.totalPrice) * 0.1),
            description: `نقاط مكافأة على شحنة ${shipment.trackingNumber}`,
          });
        }

        await createNotification({
          userId: ctx.user.id,
          shipmentId: input.shipmentId,
          title: paymentStatus === "paid" ? "تم تأكيد الدفع" : "جارٍ التحقق من الدفع",
          message:
            paymentStatus === "paid"
              ? `تم تأكيد دفعك وقبول شحنتك ${shipment.trackingNumber}`
              : `جارٍ التحقق من تحويلك البنكي لشحنة ${shipment.trackingNumber}`,
          type: "payment",
        });

        return { success: true };
      }),

    // Admin/Employee procedures
    all: adminProcedure
      .input(
        z.object({
          search: z.string().optional(),
          status: z.string().optional(),
          type: z.string().optional(),
          limit: z.number().default(50),
          offset: z.number().default(0),
        })
      )
      .query(async ({ input }) => {
        return getAllShipments(input);
      }),

    stats: adminProcedure.query(async () => {
      return getShipmentStats();
    }),

    updateStatus: employeeProcedure
      .input(
        z.object({
          shipmentId: z.number(),
          status: z.enum([
            "pending",
            "confirmed",
            "picked_up",
            "in_transit",
            "out_for_delivery",
            "delivered",
            "failed",
            "cancelled",
          ]),
          location: z.string().optional(),
          lat: z.number().optional(),
          lng: z.number().optional(),
          description: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const shipment = await getShipmentById(input.shipmentId);
        if (!shipment) throw new TRPCError({ code: "NOT_FOUND" });

        await updateShipmentStatus(input.shipmentId, input.status, input.location, input.lat, input.lng);

        const statusLabels: Record<string, string> = {
          pending: "قيد الانتظار",
          confirmed: "تم التأكيد",
          picked_up: "تم الاستلام",
          in_transit: "في الطريق",
          out_for_delivery: "خارج للتوصيل",
          delivered: "تم التسليم",
          failed: "فشل التسليم",
          cancelled: "ملغاة",
        };

        await addShipmentEvent({
          shipmentId: input.shipmentId,
          status: input.status,
          description: input.description || `تم تحديث حالة الشحنة إلى: ${statusLabels[input.status]}`,
          location: input.location,
          lat: input.lat?.toString() as any,
          lng: input.lng?.toString() as any,
          createdBy: ctx.user.id,
        });

        await createNotification({
          userId: shipment.userId,
          shipmentId: input.shipmentId,
          title: "تحديث حالة الشحنة",
          message: `شحنتك ${shipment.trackingNumber} - ${statusLabels[input.status]}`,
          type: "status_update",
        });

        if (input.status === "delivered") {
          await addPointsTransaction({
            userId: shipment.userId,
            shipmentId: input.shipmentId,
            type: "bonus",
            points: 50,
            description: `مكافأة التسليم الناجح لشحنة ${shipment.trackingNumber}`,
          });
        }

        return { success: true };
      }),

    employeeShipments: employeeProcedure.query(async ({ ctx }) => {
      return getEmployeeShipments(ctx.user.id);
    }),

    events: publicProcedure
      .input(z.object({ shipmentId: z.number() }))
      .query(async ({ input }) => {
        return getShipmentEvents(input.shipmentId);
      }),
  }),

  // ─── Admin router (matches AdminDashboard.tsx usage) ──────────────────────
  admin: router({
    stats: adminProcedure.query(async () => {
      return getShipmentStats();
    }),

    shipments: adminProcedure
      .input(
        z.object({
          page: z.number().default(1),
          limit: z.number().default(15),
          search: z.string().optional(),
          status: z.string().optional(),
        })
      )
      .query(async ({ input }) => {
        const offset = (input.page - 1) * input.limit;
        const result = await getAllShipments({ search: input.search, status: input.status, limit: input.limit, offset });
        return { shipments: result.shipments, total: result.total };
      }),

    users: adminProcedure
      .input(z.object({ page: z.number().default(1), limit: z.number().default(20) }))
      .query(async ({ input }) => {
        const users = await getAllUsers();
        return { users, total: users.length };
      }),

    updateShipmentStatus: adminProcedure
      .input(
        z.object({
          shipmentId: z.number(),
          status: z.enum(["pending","confirmed","picked_up","in_transit","out_for_delivery","delivered","failed","cancelled"]),
          location: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const shipment = await getShipmentById(input.shipmentId);
        if (!shipment) throw new TRPCError({ code: "NOT_FOUND" });
        await updateShipmentStatus(input.shipmentId, input.status, input.location);
        await addShipmentEvent({
          shipmentId: input.shipmentId,
          status: input.status,
          description: `تم تحديث الحالة بواسطة الأدمن`,
          location: input.location,
          createdBy: ctx.user.id,
        });
        return { success: true };
      }),
  }),

  // ─── Employee router (matches EmployeeDashboard.tsx usage) ───────────────────
  employee: router({
    myAssignedShipments: employeeProcedure
      .input(z.object({ search: z.string().optional() }))
      .query(async ({ ctx, input }) => {
        const result = await getAllShipments({ search: input.search, limit: 50, offset: 0 });
        return { shipments: result.shipments };
      }),

    updateShipmentStatus: employeeProcedure
      .input(
        z.object({
          shipmentId: z.number(),
          status: z.enum(["pending","confirmed","picked_up","in_transit","out_for_delivery","delivered","failed","cancelled"]),
          location: z.string().optional(),
          notes: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const shipment = await getShipmentById(input.shipmentId);
        if (!shipment) throw new TRPCError({ code: "NOT_FOUND" });
        await updateShipmentStatus(input.shipmentId, input.status, input.location);
        const statusLabels: Record<string, string> = {
          pending: "قيد الانتظار", confirmed: "تم التأكيد", picked_up: "تم الاستلام",
          in_transit: "في الطريق", out_for_delivery: "خارج للتوصيل",
          delivered: "تم التسليم", failed: "فشل التسليم", cancelled: "ملغاة",
        };
        await addShipmentEvent({
          shipmentId: input.shipmentId,
          status: input.status,
          description: input.notes || `تم تحديث الحالة إلى: ${statusLabels[input.status]}`,
          location: input.location,
          createdBy: ctx.user.id,
        });
        await createNotification({
          userId: shipment.userId,
          shipmentId: input.shipmentId,
          title: "تحديث حالة الشحنة",
          message: `شحنتك ${shipment.trackingNumber} - ${statusLabels[input.status]}`,
          type: "status_update",
        });
        if (input.status === "delivered") {
          await addPointsTransaction({
            userId: shipment.userId,
            shipmentId: input.shipmentId,
            type: "bonus",
            points: 50,
            description: `مكافأة التسليم الناجح لشحنة ${shipment.trackingNumber}`,
          });
        }
        return { success: true };
      }),
  }),

  // ─── Users (Admin) ─────────────────────────────────────────────────────────
  users: router({
    all: adminProcedure
      .input(z.object({ search: z.string().optional() }))
      .query(async ({ input }) => {
        return getAllUsers(input.search);
      }),

    updateRole: adminProcedure
      .input(
        z.object({
          userId: z.number(),
          role: z.enum(["user", "admin", "employee"]),
        })
      )
      .mutation(async ({ input }) => {
        await updateUserRole(input.userId, input.role);
        return { success: true };
      }),
  }),

  // ─── Points ────────────────────────────────────────────────────────────────
  points: router({
    myHistory: protectedProcedure.query(async ({ ctx }) => {
      return getUserPointsHistory(ctx.user.id);
    }),

    myBalance: protectedProcedure.query(async ({ ctx }) => {
      return { points: ctx.user.points, level: ctx.user.level };
    }),
  }),

  // ─── Notifications ─────────────────────────────────────────────────────────
  notifications: router({
    myNotifications: protectedProcedure.query(async ({ ctx }) => {
      return getUserNotifications(ctx.user.id);
    }),

    unreadCount: protectedProcedure.query(async ({ ctx }) => {
      const count = await getUnreadNotificationsCount(ctx.user.id);
      return { count };
    }),

    markRead: protectedProcedure
      .input(z.object({ notificationId: z.number() }))
      .mutation(async ({ input }) => {
        await markNotificationRead(input.notificationId);
        return { success: true };
      }),

    markAllRead: protectedProcedure.mutation(async ({ ctx }) => {
      await markAllNotificationsRead(ctx.user.id);
      return { success: true };
    }),
  }),
});

export type AppRouter = typeof appRouter;
