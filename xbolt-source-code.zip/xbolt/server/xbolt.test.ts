import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import { COOKIE_NAME } from "../shared/const";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createUserContext(role: "user" | "admin" | "employee" = "user"): { ctx: TrpcContext; clearedCookies: any[] } {
  const clearedCookies: any[] = [];
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user-openid",
    email: "test@xbolt.com",
    name: "مستخدم تجريبي",
    loginMethod: "manus",
    role,
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {
      clearCookie: (name: string, options: Record<string, unknown>) => {
        clearedCookies.push({ name, options });
      },
    } as TrpcContext["res"],
  };

  return { ctx, clearedCookies };
}

// ─── Auth Tests ───────────────────────────────────────────────────────────────
describe("auth.logout", () => {
  it("clears session cookie and returns success", async () => {
    const { ctx, clearedCookies } = createUserContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.logout();

    expect(result).toEqual({ success: true });
    expect(clearedCookies).toHaveLength(1);
    expect(clearedCookies[0]?.name).toBe(COOKIE_NAME);
    expect(clearedCookies[0]?.options).toMatchObject({ maxAge: -1 });
  });

  it("returns current user from auth.me", async () => {
    const { ctx } = createUserContext("admin");
    const caller = appRouter.createCaller(ctx);
    const user = await caller.auth.me();

    expect(user).toBeDefined();
    expect(user?.role).toBe("admin");
    expect(user?.email).toBe("test@xbolt.com");
  });
});

// ─── Price Calculation Tests ──────────────────────────────────────────────────
describe("shipments.calculatePrice", () => {
  it("calculates local shipment base price correctly", async () => {
    const { ctx } = createUserContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.shipments.calculatePrice({
      type: "local",
      weight: 1,
      expressDelivery: false,
      insurance: false,
      packagingService: false,
      signatureRequired: false,
    });

    expect(result.basePrice).toBe(25);
    expect(result.extraServicesPrice).toBe(0);
    expect(result.totalPrice).toBe(25);
  });

  it("calculates international shipment with extra services", async () => {
    const { ctx } = createUserContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.shipments.calculatePrice({
      type: "international",
      weight: 2,
      expressDelivery: true,
      insurance: true,
      packagingService: false,
      signatureRequired: false,
    });

    // base: 80 + 15 (extra kg) = 95
    // express: 50, insurance: 15 → extras = 65
    expect(result.basePrice).toBe(95);
    expect(result.extraServicesPrice).toBe(65);
    expect(result.totalPrice).toBe(160);
  });

  it("calculates local shipment with heavy weight", async () => {
    const { ctx } = createUserContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.shipments.calculatePrice({
      type: "local",
      weight: 5,
      expressDelivery: false,
      insurance: false,
      packagingService: false,
      signatureRequired: false,
    });

    // base: 25 + (4 * 5) = 45
    expect(result.basePrice).toBe(45);
    expect(result.totalPrice).toBe(45);
  });

  it("adds all extra services correctly", async () => {
    const { ctx } = createUserContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.shipments.calculatePrice({
      type: "local",
      weight: 1,
      expressDelivery: true,
      insurance: true,
      packagingService: true,
      signatureRequired: true,
    });

    // extras: 20 + 15 + 10 + 5 = 50
    expect(result.extraServicesPrice).toBe(50);
    expect(result.totalPrice).toBe(75);
  });
});

// ─── Admin Guard Tests ────────────────────────────────────────────────────────
describe("admin procedures", () => {
  it("blocks non-admin users from admin.stats", async () => {
    const { ctx } = createUserContext("user");
    const caller = appRouter.createCaller(ctx);

    await expect(caller.admin.stats()).rejects.toThrow();
  });

  it("allows admin users to access admin.stats", async () => {
    const { ctx } = createUserContext("admin");
    const caller = appRouter.createCaller(ctx);

    // This will fail at DB level (no DB in test), but should not throw FORBIDDEN
    try {
      await caller.admin.stats();
    } catch (err: any) {
      // Should NOT be a FORBIDDEN error
      expect(err?.data?.code).not.toBe("FORBIDDEN");
    }
  });
});

// ─── Employee Guard Tests ─────────────────────────────────────────────────────
describe("employee procedures", () => {
  it("blocks regular users from employee procedures", async () => {
    const { ctx } = createUserContext("user");
    const caller = appRouter.createCaller(ctx);

    await expect(caller.employee.myAssignedShipments({ search: undefined })).rejects.toThrow();
  });

  it("allows employees to access employee procedures", async () => {
    const { ctx } = createUserContext("employee");
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.employee.myAssignedShipments({ search: undefined });
    } catch (err: any) {
      expect(err?.data?.code).not.toBe("FORBIDDEN");
    }
  });
});
