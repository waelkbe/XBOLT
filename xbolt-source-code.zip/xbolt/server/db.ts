import { eq, desc, and, like, or, sql, count, sum } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  users,
  shipments,
  InsertShipment,
  shipmentEvents,
  InsertShipmentEvent,
  pointsTransactions,
  InsertPointsTransaction,
  notifications,
  InsertNotification,
} from "../drizzle/schema";
import { ENV } from "./_core/env";
import { nanoid } from "nanoid";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─── Users ───────────────────────────────────────────────────────────────────

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};

  const textFields = ["name", "email", "loginMethod", "phone"] as const;
  type TextField = (typeof textFields)[number];

  const assignNullable = (field: TextField) => {
    const value = user[field];
    if (value === undefined) return;
    const normalized = value ?? null;
    values[field] = normalized;
    updateSet[field] = normalized;
  };
  textFields.forEach(assignNullable);

  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }

  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function getAllUsers(search?: string) {
  const db = await getDb();
  if (!db) return [];
  if (search) {
    return db
      .select()
      .from(users)
      .where(
        or(
          like(users.name, `%${search}%`),
          like(users.email, `%${search}%`),
          like(users.phone, `%${search}%`)
        )
      )
      .orderBy(desc(users.createdAt));
  }
  return db.select().from(users).orderBy(desc(users.createdAt));
}

export async function updateUserRole(userId: number, role: "user" | "admin" | "employee") {
  const db = await getDb();
  if (!db) return;
  await db.update(users).set({ role }).where(eq(users.id, userId));
}

export async function updateUserPoints(userId: number, points: number) {
  const db = await getDb();
  if (!db) return;
  const user = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  if (!user[0]) return;
  const newPoints = (user[0].points || 0) + points;
  let level: "bronze" | "silver" | "gold" | "platinum" = "bronze";
  if (newPoints >= 5000) level = "platinum";
  else if (newPoints >= 2000) level = "gold";
  else if (newPoints >= 500) level = "silver";
  await db.update(users).set({ points: newPoints, level }).where(eq(users.id, userId));
}

// ─── Shipments ────────────────────────────────────────────────────────────────

function generateTrackingNumber(): string {
  const prefix = "XB";
  const timestamp = Date.now().toString(36).toUpperCase();
  const random = nanoid(4).toUpperCase();
  return `${prefix}${timestamp}${random}`;
}

export async function createShipment(data: Omit<InsertShipment, "trackingNumber">) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const trackingNumber = generateTrackingNumber();
  await db.insert(shipments).values({ ...data, trackingNumber });
  const result = await db
    .select()
    .from(shipments)
    .where(eq(shipments.trackingNumber, trackingNumber))
    .limit(1);
  return result[0];
}

export async function getShipmentById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(shipments).where(eq(shipments.id, id)).limit(1);
  return result[0];
}

export async function getShipmentByTracking(trackingNumber: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(shipments)
    .where(eq(shipments.trackingNumber, trackingNumber))
    .limit(1);
  return result[0];
}

export async function getUserShipments(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(shipments)
    .where(eq(shipments.userId, userId))
    .orderBy(desc(shipments.createdAt));
}

export async function getAllShipments(opts?: {
  search?: string;
  status?: string;
  type?: string;
  limit?: number;
  offset?: number;
}) {
  const db = await getDb();
  if (!db) return { shipments: [], total: 0 };
  const conditions = [];
  if (opts?.search) {
    conditions.push(
      or(
        like(shipments.trackingNumber, `%${opts.search}%`),
        like(shipments.senderName, `%${opts.search}%`),
        like(shipments.receiverName, `%${opts.search}%`)
      )
    );
  }
  if (opts?.status) conditions.push(eq(shipments.status, opts.status as any));
  if (opts?.type) conditions.push(eq(shipments.type, opts.type as any));

  const query = db
    .select()
    .from(shipments)
    .orderBy(desc(shipments.createdAt))
    .limit(opts?.limit ?? 50)
    .offset(opts?.offset ?? 0);

  let rows;
  if (conditions.length > 0) {
    rows = await query.where(and(...(conditions as any)));
  } else {
    rows = await query;
  }
  return { shipments: rows, total: rows.length };
}

export async function getEmployeeShipments(employeeId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(shipments)
    .where(eq(shipments.employeeId, employeeId))
    .orderBy(desc(shipments.createdAt));
}

export async function updateShipmentStatus(
  shipmentId: number,
  status: string,
  location?: string,
  lat?: number,
  lng?: number
) {
  const db = await getDb();
  if (!db) return;
  const updateData: Record<string, any> = { status };
  if (location) updateData.currentLocation = location;
  if (lat !== undefined) updateData.currentLat = lat.toString();
  if (lng !== undefined) updateData.currentLng = lng.toString();
  await db.update(shipments).set(updateData).where(eq(shipments.id, shipmentId));
}

export async function updateShipmentPayment(
  shipmentId: number,
  paymentMethod: string,
  paymentStatus: string,
  paymentProofUrl?: string
) {
  const db = await getDb();
  if (!db) return;
  await db
    .update(shipments)
    .set({ paymentMethod: paymentMethod as any, paymentStatus: paymentStatus as any, paymentProofUrl })
    .where(eq(shipments.id, shipmentId));
}

export async function getShipmentStats() {
  const db = await getDb();
  if (!db) return null;
  const [total] = await db.select({ count: count() }).from(shipments);
  const [delivered] = await db
    .select({ count: count() })
    .from(shipments)
    .where(eq(shipments.status, "delivered"));
  const [pending] = await db
    .select({ count: count() })
    .from(shipments)
    .where(eq(shipments.status, "pending"));
  const [revenue] = await db
    .select({ total: sum(shipments.totalPrice) })
    .from(shipments)
    .where(eq(shipments.paymentStatus, "paid"));
  const [usersCount] = await db.select({ count: count() }).from(users);

  const [inTransit] = await db.select({ count: count() }).from(shipments).where(eq(shipments.status, "in_transit"));
  const [outForDelivery] = await db.select({ count: count() }).from(shipments).where(eq(shipments.status, "out_for_delivery"));
  const [confirmed] = await db.select({ count: count() }).from(shipments).where(eq(shipments.status, "confirmed"));
  const [pickedUp] = await db.select({ count: count() }).from(shipments).where(eq(shipments.status, "picked_up"));
  const [failed] = await db.select({ count: count() }).from(shipments).where(eq(shipments.status, "failed"));
  const [cancelled] = await db.select({ count: count() }).from(shipments).where(eq(shipments.status, "cancelled"));

  return {
    totalShipments: total.count,
    deliveredShipments: delivered.count,
    pendingShipments: pending.count,
    activeShipments: (inTransit.count + outForDelivery.count + confirmed.count + pickedUp.count),
    totalRevenue: revenue.total ?? "0",
    totalUsers: usersCount.count,
    statusBreakdown: {
      pending: pending.count,
      confirmed: confirmed.count,
      picked_up: pickedUp.count,
      in_transit: inTransit.count,
      out_for_delivery: outForDelivery.count,
      delivered: delivered.count,
      failed: failed.count,
      cancelled: cancelled.count,
    },
  };
}

// ─── Shipment Events ─────────────────────────────────────────────────────────

export async function addShipmentEvent(data: InsertShipmentEvent) {
  const db = await getDb();
  if (!db) return;
  await db.insert(shipmentEvents).values(data);
}

export async function getShipmentEvents(shipmentId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(shipmentEvents)
    .where(eq(shipmentEvents.shipmentId, shipmentId))
    .orderBy(desc(shipmentEvents.createdAt));
}

// ─── Points Transactions ──────────────────────────────────────────────────────

export async function addPointsTransaction(data: InsertPointsTransaction) {
  const db = await getDb();
  if (!db) return;
  await db.insert(pointsTransactions).values(data);
  await updateUserPoints(data.userId, data.points);
}

export async function getUserPointsHistory(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(pointsTransactions)
    .where(eq(pointsTransactions.userId, userId))
    .orderBy(desc(pointsTransactions.createdAt));
}

// ─── Notifications ────────────────────────────────────────────────────────────

export async function createNotification(data: InsertNotification) {
  const db = await getDb();
  if (!db) return;
  await db.insert(notifications).values(data);
}

export async function getUserNotifications(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(notifications)
    .where(eq(notifications.userId, userId))
    .orderBy(desc(notifications.createdAt))
    .limit(50);
}

export async function markNotificationRead(notificationId: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(notifications).set({ isRead: true }).where(eq(notifications.id, notificationId));
}

export async function markAllNotificationsRead(userId: number) {
  const db = await getDb();
  if (!db) return;
  await db
    .update(notifications)
    .set({ isRead: true })
    .where(and(eq(notifications.userId, userId), eq(notifications.isRead, false)));
}

export async function getUnreadNotificationsCount(userId: number) {
  const db = await getDb();
  if (!db) return 0;
  const [result] = await db
    .select({ count: count() })
    .from(notifications)
    .where(and(eq(notifications.userId, userId), eq(notifications.isRead, false)));
  return result.count;
}
