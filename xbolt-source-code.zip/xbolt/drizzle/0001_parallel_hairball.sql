CREATE TABLE `notifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`shipmentId` int,
	`title` varchar(256) NOT NULL,
	`message` text NOT NULL,
	`type` enum('status_update','payment','delivery','points','system') NOT NULL DEFAULT 'system',
	`isRead` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `notifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `points_transactions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`shipmentId` int,
	`type` enum('earn','redeem','bonus','expire') NOT NULL,
	`points` int NOT NULL,
	`description` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `points_transactions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `shipment_events` (
	`id` int AUTO_INCREMENT NOT NULL,
	`shipmentId` int NOT NULL,
	`status` varchar(64) NOT NULL,
	`description` text NOT NULL,
	`location` varchar(256),
	`lat` decimal(10,7),
	`lng` decimal(10,7),
	`createdBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `shipment_events_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `shipments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`trackingNumber` varchar(32) NOT NULL,
	`userId` int NOT NULL,
	`employeeId` int,
	`type` enum('local','international') NOT NULL,
	`status` enum('pending','confirmed','picked_up','in_transit','out_for_delivery','delivered','failed','cancelled','pending_payment') NOT NULL DEFAULT 'pending',
	`senderName` varchar(128) NOT NULL,
	`senderPhone` varchar(20) NOT NULL,
	`senderEmail` varchar(320),
	`senderCountry` varchar(64) NOT NULL,
	`senderCity` varchar(64) NOT NULL,
	`senderAddress` text NOT NULL,
	`senderDistrict` varchar(128),
	`senderPostalCode` varchar(20),
	`receiverName` varchar(128) NOT NULL,
	`receiverPhone` varchar(20) NOT NULL,
	`receiverEmail` varchar(320),
	`receiverCountry` varchar(64) NOT NULL,
	`receiverCity` varchar(64) NOT NULL,
	`receiverAddress` text NOT NULL,
	`receiverDistrict` varchar(128),
	`receiverPostalCode` varchar(20),
	`packageType` enum('document','parcel','fragile','heavy') NOT NULL DEFAULT 'parcel',
	`weight` decimal(8,2) NOT NULL,
	`length` decimal(8,2),
	`width` decimal(8,2),
	`height` decimal(8,2),
	`description` text,
	`declaredValue` decimal(10,2),
	`insurance` boolean DEFAULT false,
	`expressDelivery` boolean DEFAULT false,
	`signatureRequired` boolean DEFAULT false,
	`packagingService` boolean DEFAULT false,
	`basePrice` decimal(10,2) NOT NULL,
	`extraServicesPrice` decimal(10,2) DEFAULT '0',
	`totalPrice` decimal(10,2) NOT NULL,
	`currency` varchar(8) NOT NULL DEFAULT 'SAR',
	`paymentMethod` enum('online','bank_transfer','cash'),
	`paymentStatus` enum('pending','paid','failed','refunded') NOT NULL DEFAULT 'pending',
	`paymentProofUrl` text,
	`currentLat` decimal(10,7),
	`currentLng` decimal(10,7),
	`currentLocation` varchar(256),
	`notes` text,
	`estimatedDelivery` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `shipments_id` PRIMARY KEY(`id`),
	CONSTRAINT `shipments_trackingNumber_unique` UNIQUE(`trackingNumber`)
);
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` enum('user','admin','employee') NOT NULL DEFAULT 'user';--> statement-breakpoint
ALTER TABLE `users` ADD `phone` varchar(20);--> statement-breakpoint
ALTER TABLE `users` ADD `points` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `level` enum('bronze','silver','gold','platinum') DEFAULT 'bronze' NOT NULL;