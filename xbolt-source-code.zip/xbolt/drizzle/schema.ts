import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  decimal,
  boolean,
  json,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 20 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin", "employee"]).default("user").notNull(),
  points: int("points").default(0).notNull(),
  level: mysqlEnum("level", ["bronze", "silver", "gold", "platinum"]).default("bronze").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const shipments = mysqlTable("shipments", {
  id: int("id").autoincrement().primaryKey(),
  trackingNumber: varchar("trackingNumber", { length: 32 }).notNull().unique(),
  userId: int("userId").notNull(),
  employeeId: int("employeeId"),
  type: mysqlEnum("type", ["local", "international"]).notNull(),
  status: mysqlEnum("status", [
    "pending",
    "confirmed",
    "picked_up",
    "in_transit",
    "out_for_delivery",
    "delivered",
    "failed",
    "cancelled",
    "pending_payment",
  ]).default("pending").notNull(),

  // Sender info
  senderName: varchar("senderName", { length: 128 }).notNull(),
  senderPhone: varchar("senderPhone", { length: 20 }).notNull(),
  senderEmail: varchar("senderEmail", { length: 320 }),
  senderCountry: varchar("senderCountry", { length: 64 }).notNull(),
  senderCity: varchar("senderCity", { length: 64 }).notNull(),
  senderAddress: text("senderAddress").notNull(),
  senderDistrict: varchar("senderDistrict", { length: 128 }),
  senderPostalCode: varchar("senderPostalCode", { length: 20 }),

  // Receiver info
  receiverName: varchar("receiverName", { length: 128 }).notNull(),
  receiverPhone: varchar("receiverPhone", { length: 20 }).notNull(),
  receiverEmail: varchar("receiverEmail", { length: 320 }),
  receiverCountry: varchar("receiverCountry", { length: 64 }).notNull(),
  receiverCity: varchar("receiverCity", { length: 64 }).notNull(),
  receiverAddress: text("receiverAddress").notNull(),
  receiverDistrict: varchar("receiverDistrict", { length: 128 }),
  receiverPostalCode: varchar("receiverPostalCode", { length: 20 }),

  // Package details
  packageType: mysqlEnum("packageType", ["document", "parcel", "fragile", "heavy"]).default("parcel").notNull(),
  weight: decimal("weight", { precision: 8, scale: 2 }).notNull(),
  length: decimal("length", { precision: 8, scale: 2 }),
  width: decimal("width", { precision: 8, scale: 2 }),
  height: decimal("height", { precision: 8, scale: 2 }),
  description: text("description"),
  declaredValue: decimal("declaredValue", { precision: 10, scale: 2 }),

  // Extra services
  insurance: boolean("insurance").default(false),
  expressDelivery: boolean("expressDelivery").default(false),
  signatureRequired: boolean("signatureRequired").default(false),
  packagingService: boolean("packagingService").default(false),

  // Pricing
  basePrice: decimal("basePrice", { precision: 10, scale: 2 }).notNull(),
  extraServicesPrice: decimal("extraServicesPrice", { precision: 10, scale: 2 }).default("0"),
  totalPrice: decimal("totalPrice", { precision: 10, scale: 2 }).notNull(),
  currency: varchar("currency", { length: 8 }).default("SAR").notNull(),

  // Payment
  paymentMethod: mysqlEnum("paymentMethod", ["online", "bank_transfer", "cash"]),
  paymentStatus: mysqlEnum("paymentStatus", ["pending", "paid", "failed", "refunded"]).default("pending").notNull(),
  paymentProofUrl: text("paymentProofUrl"),

  // Location tracking
  currentLat: decimal("currentLat", { precision: 10, scale: 7 }),
  currentLng: decimal("currentLng", { precision: 10, scale: 7 }),
  currentLocation: varchar("currentLocation", { length: 256 }),

  // Notes
  notes: text("notes"),
  estimatedDelivery: timestamp("estimatedDelivery"),

  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Shipment = typeof shipments.$inferSelect;
export type InsertShipment = typeof shipments.$inferInsert;

export const shipmentEvents = mysqlTable("shipment_events", {
  id: int("id").autoincrement().primaryKey(),
  shipmentId: int("shipmentId").notNull(),
  status: varchar("status", { length: 64 }).notNull(),
  description: text("description").notNull(),
  location: varchar("location", { length: 256 }),
  lat: decimal("lat", { precision: 10, scale: 7 }),
  lng: decimal("lng", { precision: 10, scale: 7 }),
  createdBy: int("createdBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ShipmentEvent = typeof shipmentEvents.$inferSelect;
export type InsertShipmentEvent = typeof shipmentEvents.$inferInsert;

export const pointsTransactions = mysqlTable("points_transactions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  shipmentId: int("shipmentId"),
  type: mysqlEnum("type", ["earn", "redeem", "bonus", "expire"]).notNull(),
  points: int("points").notNull(),
  description: text("description").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PointsTransaction = typeof pointsTransactions.$inferSelect;
export type InsertPointsTransaction = typeof pointsTransactions.$inferInsert;

export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  shipmentId: int("shipmentId"),
  title: varchar("title", { length: 256 }).notNull(),
  message: text("message").notNull(),
  type: mysqlEnum("type", ["status_update", "payment", "delivery", "points", "system"]).default("system").notNull(),
  isRead: boolean("isRead").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;

// ─── Guest Sessions (OTP-based checkout without registration) ─────────────────
export const guestSessions = mysqlTable("guest_sessions", {
  id: int("id").autoincrement().primaryKey(),
  email: varchar("email", { length: 320 }).notNull(),
  phone: varchar("phone", { length: 20 }),
  otpCode: varchar("otpCode", { length: 6 }).notNull(),
  otpExpiresAt: timestamp("otpExpiresAt").notNull(),
  isVerified: boolean("isVerified").default(false).notNull(),
  sessionToken: varchar("sessionToken", { length: 128 }),
  tokenExpiresAt: timestamp("tokenExpiresAt"),
  attempts: int("attempts").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type GuestSession = typeof guestSessions.$inferSelect;
export type InsertGuestSession = typeof guestSessions.$inferInsert;

// ─── Guest Shipments (shipments created by guests) ────────────────────────────
export const guestShipments = mysqlTable("guest_shipments", {
  id: int("id").autoincrement().primaryKey(),
  trackingNumber: varchar("trackingNumber", { length: 32 }).notNull().unique(),
  guestEmail: varchar("guestEmail", { length: 320 }).notNull(),
  guestPhone: varchar("guestPhone", { length: 20 }),
  guestName: varchar("guestName", { length: 128 }).notNull(),
  type: mysqlEnum("type", ["local", "international"]).notNull(),
  status: mysqlEnum("status", [
    "pending",
    "confirmed",
    "picked_up",
    "in_transit",
    "out_for_delivery",
    "delivered",
    "failed",
    "cancelled",
    "pending_payment",
  ]).default("pending").notNull(),

  // Sender info
  senderName: varchar("senderName", { length: 128 }).notNull(),
  senderPhone: varchar("senderPhone", { length: 20 }).notNull(),
  senderEmail: varchar("senderEmail", { length: 320 }),
  senderCountry: varchar("senderCountry", { length: 64 }).notNull(),
  senderCity: varchar("senderCity", { length: 64 }).notNull(),
  senderAddress: text("senderAddress").notNull(),
  senderDistrict: varchar("senderDistrict", { length: 128 }),
  senderPostalCode: varchar("senderPostalCode", { length: 20 }),
  senderShortAddress: varchar("senderShortAddress", { length: 128 }),

  // Receiver info
  receiverName: varchar("receiverName", { length: 128 }).notNull(),
  receiverPhone: varchar("receiverPhone", { length: 20 }).notNull(),
  receiverEmail: varchar("receiverEmail", { length: 320 }),
  receiverCountry: varchar("receiverCountry", { length: 64 }).notNull(),
  receiverCity: varchar("receiverCity", { length: 64 }).notNull(),
  receiverAddress: text("receiverAddress").notNull(),
  receiverDistrict: varchar("receiverDistrict", { length: 128 }),
  receiverPostalCode: varchar("receiverPostalCode", { length: 20 }),
  receiverShortAddress: varchar("receiverShortAddress", { length: 128 }),

  // Package details
  packageType: mysqlEnum("packageType", ["document", "parcel", "fragile", "heavy"]).default("parcel").notNull(),
  weight: decimal("weight", { precision: 8, scale: 2 }).notNull(),
  length: decimal("length", { precision: 8, scale: 2 }),
  width: decimal("width", { precision: 8, scale: 2 }),
  height: decimal("height", { precision: 8, scale: 2 }),
  description: text("description"),
  declaredValue: decimal("declaredValue", { precision: 10, scale: 2 }),

  // Extra services
  insurance: boolean("insurance").default(false),
  expressDelivery: boolean("expressDelivery").default(false),
  signatureRequired: boolean("signatureRequired").default(false),
  packagingService: boolean("packagingService").default(false),

  // Pricing
  basePrice: decimal("basePrice", { precision: 10, scale: 2 }).notNull(),
  extraServicesPrice: decimal("extraServicesPrice", { precision: 10, scale: 2 }).default("0"),
  totalPrice: decimal("totalPrice", { precision: 10, scale: 2 }).notNull(),
  currency: varchar("currency", { length: 8 }).default("SAR").notNull(),

  // Payment
  paymentMethod: mysqlEnum("paymentMethod", ["online", "bank_transfer", "cash"]),
  paymentStatus: mysqlEnum("paymentStatus", ["pending", "paid", "failed", "refunded"]).default("pending").notNull(),
  paymentProofUrl: text("paymentProofUrl"),

  notes: text("notes"),
  estimatedDelivery: timestamp("estimatedDelivery"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type GuestShipment = typeof guestShipments.$inferSelect;
export type InsertGuestShipment = typeof guestShipments.$inferInsert;
